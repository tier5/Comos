<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;
use Validator;
use App\Posts;
use App\Tags;
use App\Category;
use Auth;

class PostsController extends Controller
{
    public function index()
    {
        $posts = Posts::orderBy('created_at', 'desc')->paginate(5);
        return view('backend.posts.index')->withPosts($posts);
    }

    public function create()
    {
        $categories = Category::all();
        $tags = Tags::all();
        return view('backend.posts.create')->withCategories($categories)->withTags($tags);
    }

    public function store(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'title' => 'required|unique:posts|max:255',
            'date' => 'required',
            'category' => 'required'
        ]);

        if( $validator->fails() ) {
            return redirect()->back()->withErrors($validator);
        }

        $posts = new Posts;
        $posts->title = $request->title;
        $posts->slug = str_slug($request->title);
        $posts->author = Auth::user()->name;
        $posts->content = $request->content;
        $posts->status = $request->status;
        $posts->category = $request->category;
        $posts->tags = $request->tags;
        $posts->date = $request->date;
        $posts->save();

        Session::flash('success', 'Successfully created new post!');
        return redirect()->route('posts.index');
    }

    public function edit($id)
    {
        $categories = Category::all();
        $tags = Tags::all();
        $post = Posts::findOrFail($id);
        return view('backend.posts.edit')->withPost($post)->withCategories($categories)->withTags($tags);
    }

    public function update(Request $request, $id)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'title' => 'required',
            'slug' => 'required',
            'content' => 'required',
            'date' => 'required'
        ]);

        if( $validator->fails() ) {
            return redirect()->back()->withErrors($validator);
        }

        $post = Posts::findOrFail($id);
        $post->fill($input)->save();
        Session::flash('success', 'Successfully updated the post!');
        return redirect()->route('posts.index');
    }

    public function destroy($id) 
    {
        $posts = Posts::findOrFail($id);
        $posts->delete();

        Session::flash('success', 'Successfully deleted the post!');
        return redirect()->route('posts.index');
    }

    public function postDeleteAll() 
    {
        Posts::truncate();
        Session::flash('success', 'Successfully deleted all the posts!');
        return redirect()->route('posts.index');
    }
}
