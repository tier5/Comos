<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\Posts;
use Validator;
use Session;
use App\User;
use Hash;

class PagesController extends Controller
{
    public function login()
    {
        if(Auth::check()) {
            return redirect()->route('dashboard.index');
        }

        return view('frontend.pages.login');
    }

    public function authenticate(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required'
        ]);

        if($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            Session::flash('success', 'Successfully logged in!');
            return redirect()->intended('dashboard');
        } else {
            Session::flash('error', 'Invalid login credentials!');
            return redirect()->back();
        }
    }

    public function logout()
    {
        Auth::logout();

        Session::flash('success', 'Successfully logged out!');
        return redirect()->route('login');
    }

    public function home()
    {
        return view('frontend.pages.home');
    }

    public function latest()
    {  
        $posts = Posts::where('status', 'public')->orderBy('created_at', 'desc')->paginate(5);
        return view('frontend.pages.latest')->withPosts($posts);
    }

    public function single($id)
    {
        $post = Posts::findOrFail($id);
        return view('frontend.pages.single')->withPost($post);
    }
}
