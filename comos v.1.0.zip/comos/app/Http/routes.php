<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::group(['middleware' => 'auth'], function () {
	//dashboard routes
	Route::resource('dashboard', 'DashboardController');
	Route::resource('posts', 'PostsController');
	Route::resource('category', 'CategoryController');
	Route::resource('tags', 'TagsController');
	Route::resource('user', 'UserController');
	Route::delete('post/delete', ['uses' => 'PostsController@postDeleteAll', 'as' => 'postDeleteAll']);
	Route::delete('categories/delete', ['uses' => 'CategoryController@categoryDeleteAll', 'as' => 'categoryDeleteAll']);
	Route::delete('tag/delete', ['uses' => 'TagsController@tagsDeleteAll', 'as' => 'tagsDeleteAll']);
});

//frontend pages
Route::get('auth/login', ['uses' => 'PagesController@login', 'as' => 'login']);
Route::post('auth/login', ['uses' => 'PagesController@authenticate', 'as' => 'authenticate']);
Route::get('auth/logout', ['uses' => 'PagesController@logout', 'as' => 'logout']);

Route::get('/', ['uses' => 'PagesController@home', 'as' => 'home']);
Route::get('latest-posts', ['uses' => 'PagesController@latest', 'as' => 'latest']);
Route::get('post/{id}', ['uses' => 'PagesController@single', 'as' => 'single']);

//installation
Route::get('setup', ['uses' => 'DashboardController@setup', 'as' => 'setup']);
Route::post('install', ['uses' => 'DashboardController@install', 'as' => 'install']);