@extends('frontend.master')
@section('title', 'Page Not Found')
@section('class', 'page404')
@section('header')
<meta name="robots" content="noindex,nofollow" />
@endsection
@section('main') 
<div class="col-md-4 col-md-offset-4">
	<h1>404</h1>
	<h2>Page Not Found</h2>
</div>
@endsection