@extends('frontend.master')
@section('title', 'Home')
@section('class', 'home')
@section('main') 
	<div class="row">
		<h1>{{Config('app.name')}}</h1>
		<p>{{Config('app.description')}}</p>
		<a class="btn btn-danger" href="{{route('latest')}}">Latest Posts</a>
	</div>
@endsection